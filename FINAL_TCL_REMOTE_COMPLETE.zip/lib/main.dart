import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:multicast_dns/multicast_dns.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

void main() {
  runApp(const TclProRemoteApp());
}

class TclProRemoteApp extends StatelessWidget {
  const TclProRemoteApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Remote Control TCL TV',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const RemoteHome(),
    );
  }
}

class RemoteHome extends StatefulWidget {
  const RemoteHome({super.key});
  @override
  State<RemoteHome> createState() => _RemoteHomeState();
}

class _RemoteHomeState extends State<RemoteHome> {
  final TextEditingController ipCtrl = TextEditingController();
  final TextEditingController txtCtrl = TextEditingController();
  String _tvIp = '';
  bool gaming = false;
  double sensitivity = 12.0;
  final Duration throttle = const Duration(milliseconds: 100);
  DateTime lastCmd = DateTime.fromMillisecondsSinceEpoch(0);
  late SharedPreferences prefs;
  late StreamSubscription connectivitySub;
  ConnectivityResult conn = ConnectivityResult.none;
  FlutterBluePlus flutterBlue = FlutterBluePlus.instance;
  List<String> foundBt = [];
  StreamSubscription? scanSub;

  static const keys = {'Up','Down','Left','Right','Select','Back','Home','VolumeUp','VolumeDown','Play','Pause'};

  @override
  void initState() {
    super.initState();
    _initPrefs();
    connectivitySub = Connectivity().onConnectivityChanged.listen((c){ setState(()=>conn=c);});
  }

  Future<void> _initPrefs() async {
    prefs = await SharedPreferences.getInstance();
    setState((){
      _tvIp = prefs.getString('tv_ip') ?? '';
      ipCtrl.text = _tvIp;
      gaming = prefs.getBool('gaming') ?? false;
      sensitivity = prefs.getDouble('sensitivity') ?? 12.0;
    });
  }

  Future<void> _saveIp(String ip) async {
    _tvIp = ip;
    await prefs.setString('tv_ip', ip);
  }

  Future<void> _send(String key) async {
    if (!keys.contains(key)) return;
    if (ipCtrl.text.isNotEmpty) {
      _tvIp = ipCtrl.text.trim();
      await _saveIp(_tvIp);
    }
    if (_tvIp.isEmpty) return;
    final now = DateTime.now();
    if (now.difference(lastCmd) < throttle) return;
    lastCmd = now;
    try {
      final uri = Uri.parse('http://$_tvIp:8060/keypress/$key');
      http.post(uri).timeout(const Duration(milliseconds: 400));
    } catch (e) {}
  }

  void startScan() {
    foundBt = [];
    scanSub = flutterBlue.scanResults.listen((results){
      setState(()=> foundBt = results.map((r)=> r.device.name.isEmpty? r.device.id.id : r.device.name).toList());
    });
    flutterBlue.startScan(timeout: const Duration(seconds:4));
    Future.delayed(const Duration(seconds:4), (){ flutterBlue.stopScan(); scanSub?.cancel();});
  }

  @override
  void dispose(){
    connectivitySub.cancel();
    scanSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: const Text('Remote Control TCL TV')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          Row(children: [
            Expanded(child: TextField(controller: ipCtrl, decoration: const InputDecoration(prefixIcon: Icon(Icons.wifi), labelText: 'IP التلفاز'))),
            const SizedBox(width:8),
            ElevatedButton(onPressed: () async {
              final ip = await _discover();
              if (ip!=null) { ipCtrl.text = ip; await _saveIp(ip); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تلفاز وجد'))); }
            }, child: const Text('اكتشاف')),
          ]),
          const SizedBox(height:12),
          Expanded(child: Column(children: [
            Expanded(child: Container(decoration: BoxDecoration(color: Colors.grey[850], borderRadius: BorderRadius.circular(12)), child: GestureDetector(
              onPanUpdate: (d){ if (d.delta.dx> sensitivity) _send('Right'); else if (d.delta.dx < -sensitivity) _send('Left'); if (d.delta.dy> sensitivity) _send('Down'); else if (d.delta.dy < -sensitivity) _send('Up'); },
              onTap: ()=> _send('Select'),
              onLongPress: ()=> _send('Back'),
              child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [ Icon(Icons.touch_app, size:64), SizedBox(height:8), Text('حرك إصبعك هنا', style: TextStyle(color: Colors.grey)) ])),
            ))),
            const SizedBox(height:8),
            Container(height:80, child: ListView(scrollDirection: Axis.horizontal, children: [
              TextButton(onPressed: ()=> _send('Home'), child: const Text('Home')),
              TextButton(onPressed: ()=> _send('Back'), child: const Text('Back')),
              TextButton(onPressed: ()=> _send('Play'), child: const Text('Play')),
              TextButton(onPressed: ()=> _send('Pause'), child: const Text('Pause')),
            ]))
          ])),
          const SizedBox(height:8),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            IconButton(icon: const Icon(Icons.volume_up), onPressed: ()=> _send('VolumeUp')),
            IconButton(icon: const Icon(Icons.volume_down), onPressed: ()=> _send('VolumeDown')),
            IconButton(icon: const Icon(Icons.home), onPressed: ()=> _send('Home')),
            IconButton(icon: const Icon(Icons.settings), onPressed: ()=> startScan()),
          ]),
          const SizedBox(height:8),
          if (foundBt.isNotEmpty) SizedBox(height:60, child: ListView.builder(scrollDirection: Axis.horizontal, itemCount: foundBt.length, itemBuilder: (c,i) => Padding(padding: const EdgeInsets.all(6.0), child: Column(children: [ Text(foundBt[i], style: const TextStyle(color: Colors.white)), ])))),
          const SizedBox(height:8),
          Text(conn == ConnectivityResult.wifi ? 'متصل بشبكة Wi‑Fi' : 'تحقق من الشبكة', style: const TextStyle(color: Colors.grey)),
        ]),
      ),
    );
  }

  Future<String?> _discover() async {
    try {
      final mdns = MDnsClient();
      await mdns.start();
      await for (final PtrResourceRecord ptr in mdns.lookup<PtrResourceRecord>(ResourceRecordQuery.serverPointer('_roku._tcp.local')).timeout(const Duration(seconds:3))) {
        await for (final SRVResourceRecord srv in mdns.lookup<SRVResourceRecord>(ResourceRecordQuery.service(ptr.domainName)).timeout(const Duration(seconds:3))) {
          await for (final IPAddressResourceRecord addr in mdns.lookup<IPAddressResourceRecord>(ResourceRecordQuery.addressIPv4(srv.target)).timeout(const Duration(seconds:3))) {
            mdns.stop();
            return addr.address.address;
          }
        }
      }
      mdns.stop();
    } catch (e) {}
    return null;
  }
}
