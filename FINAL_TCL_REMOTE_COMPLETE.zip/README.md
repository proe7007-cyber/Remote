FINAL_TCL_REMOTE_COMPLETE

This is a ready-to-build Flutter project for TCL Remote.

Upload this ZIP to Codemagic (https://codemagic.io) or Appcircle (https://appcircle.io) and run the Android workflow.
